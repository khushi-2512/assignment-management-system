#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <limits.h>

typedef struct studentRecord{
    long int studetId;
    char name[20];
    char groupPartnerName[40];
    char groupId[10];
    char assignmentId[10];
    char deadline[20];
    char statusOfAssignment[30];
    float offlineEvalMarks;
    float vivaMarks;

    struct studentRecord* next;
}studentRecord;

typedef struct studentAssignmentRecord {
    char studentGroupId[5];
    char AssignmentStatus[50];
    float MarksGiven;
    struct studentAssignmentRecord* next;
}studentAssignmentRecord;

typedef struct assignmentRecord {
    char assignment_Id[4];
    char topicName[30];
    char assignment_Status[20];
    studentAssignmentRecord* studentAssignmentList;
    struct assignmentRecord* next;
}assignmentRecord;

studentRecord* createStudentRecord(char *filename) {
    FILE *fp = fopen(filename, "r");
    char line[1000];

    studentRecord *lptr, *nptr;
    lptr = NULL;

    if (fp == NULL){
        printf("Error opening file!\n");
    }

    while (fgets(line, 1000, fp)) {
        nptr = (studentRecord*)malloc(sizeof(studentRecord));

        char *token = NULL;

        token = strtok(line, ",");
        nptr->studetId = atol(token);

        token = strtok(NULL, ",");
        strcpy(nptr->name, token);

        token = strtok(NULL, ",");
        strcpy(nptr->groupPartnerName, token);

        token = strtok(NULL, ",");
        strcpy(nptr->groupId, token);

        token = strtok(NULL, ",");
        strcpy(nptr->assignmentId, token);

        token = strtok(NULL, ",");
        strcpy(nptr->deadline, token);

        token = strtok(NULL, ",");
        strcpy(nptr->statusOfAssignment, token);

        token = strtok(NULL, ",");
        nptr->offlineEvalMarks = atof(token);

        token = strtok(NULL, ",");
        nptr->vivaMarks = atof(token);

        nptr->next = lptr;
        lptr = nptr;
    }

    fclose(fp);
    return lptr;
}

assignmentRecord* createAssignmentRecord(char *filename) {
    FILE *fp = fopen(filename, "r");
    char line[1000];

    assignmentRecord *lptr, *nptr;
    lptr = NULL;
    studentAssignmentRecord *lptr2, *nptr2;
    lptr2 = NULL;

    if (fp == NULL){
        printf("Error opening file!\n");
    }

    while (fgets(line, 1000, fp)) {
        nptr = (assignmentRecord*)malloc(sizeof(assignmentRecord));
        
        char *token;
        
        token = strtok(line, ",");
        strcpy(nptr->assignment_Id, token);
        
        token = strtok(NULL, ",");
        strcpy(nptr->topicName, token);
       
        token = strtok(NULL, ",");
        strcpy(nptr->assignment_Status, token);

        nptr->studentAssignmentList = lptr2;
        
        while (fgets(line, sizeof(line), fp) && line[0] != '\n') {
            nptr2 = (studentAssignmentRecord*)malloc(sizeof(studentAssignmentRecord));

            token = strtok(line, ",");
            strcpy(nptr2->studentGroupId, token);
            
            token = strtok(NULL, ",");
            strcpy(nptr2->AssignmentStatus, token);
            
            token = strtok(NULL, ",");
            nptr2->MarksGiven = atof(token);
            
            nptr2->next = NULL;
            
            if (nptr->studentAssignmentList == NULL) {
                nptr->studentAssignmentList = nptr2; // Assign the first student assignment record
                nptr2->next = NULL;
            } 
            else {
                // Traverse the list to find the last record and append the new record
                studentAssignmentRecord* lptr2 = nptr->studentAssignmentList;
                while (lptr2->next != NULL) {
                    lptr2 = lptr2->next;
                }
                lptr2->next = nptr2;
                nptr2->next = NULL;
            }
        }

        nptr->next = lptr;
        lptr = nptr;
    }

    fclose(fp);
    return lptr;
}

void printStudentRecord(studentRecord* nptr) {
    studentRecord* lptr = nptr;
    while (lptr != NULL) {
        printf(" Student ID: %ld\n Student Name: %s\n Group Partner Name: %s\n Group ID: %s\n Assignment ID: %s\n Due Date: %s\n Status of Assignemnt: %s\n Offline Evaluation Marks: %.2f\n Viva Marks: %.2f\n\n",
                lptr->studetId, lptr->name, lptr->groupPartnerName, lptr->groupId, lptr->assignmentId, lptr->deadline, lptr->statusOfAssignment, lptr->offlineEvalMarks, lptr->vivaMarks);
        lptr =  lptr->next;
    }
}

void printMyRecord(studentRecord *lptr, long int id) {
    int flag = 0;
    while (lptr != NULL && flag == 0) {
        if (lptr->studetId == id) {
             printf(" Student ID: %ld\n Student Name: %s\n Group Partner Name: %s\n Group ID: %s\n Assignment ID: %s\n Due Date: %s\n Status of Assignemnt: %s\n Offline Evaluation Marks: %.2f\n Viva Marks: %.2f\n\n",
                lptr->studetId, lptr->name, lptr->groupPartnerName, lptr->groupId, lptr->assignmentId, lptr->deadline, lptr->statusOfAssignment, lptr->offlineEvalMarks, lptr->vivaMarks);
            flag = 1;
        }
        lptr =  lptr->next;
    }
}

void printAssignmentRecord(assignmentRecord* nptr) {
    
    while (nptr != NULL) {
        printf(" Assignment ID: %s\n", nptr->assignment_Id);
        printf(" Assignment Topic: %s\n", nptr->topicName);
        printf(" Assignment Status: %s\n", nptr->assignment_Status);
        studentAssignmentRecord* lptr = nptr->studentAssignmentList;
        while (lptr != NULL) {
            printf(" Group ID: %s\n", lptr->studentGroupId);
            printf(" Assignment Status: %s\n", lptr->AssignmentStatus);
            printf(" Marks: %.2f\n\n", lptr->MarksGiven);
            lptr = lptr->next;
        }
        printf("\n");
        nptr =  nptr->next;
    }
}

void insertRecord(char *filename1, char *filename2, studentRecord *lptr, assignmentRecord *lptr1, int numRecords) {
    FILE *fp1 = fopen(filename1, "a");
    FILE *fp2 = fopen(filename2, "a");
    char line[1000];
    
    studentRecord *nptr;
    int flag;

    for (int i = 0; i < numRecords; i++) {
        while (lptr->next != NULL) {
            lptr = lptr->next;
        }
        nptr = (studentRecord*)malloc(sizeof(studentRecord));
        
        printf("Enter Student ID:\n");
        scanf("%ld", &nptr->studetId);
        printf("Enter Student Name:\n");
        scanf(" %[^\n]", nptr->name);
        printf("Enter Group Partner Name:\n");
        scanf(" %[^\n]", nptr->groupPartnerName);
        printf("Enter Group ID:\n");
        scanf("%s", nptr->groupId);
        printf("Enter Assignment ID:\n");
        scanf("%s", nptr->assignmentId);
        printf("Enter Deadline of Assignment:\n");
        scanf(" %[^\n]", nptr->deadline);
        printf("Enter Assignment Status:\n");
        scanf("%s", nptr->statusOfAssignment);
        printf("Enter Offline Evaluation Marks Given:\n");
        scanf("%f", &nptr->offlineEvalMarks);
        printf("Enter Viva Marks:\n");
        scanf("%f", &(nptr->vivaMarks));
        
        fprintf(fp1, "\n%ld,%s,%s,%s,%s,%s,%s,%.2f,%.2f", nptr->studetId, nptr->name, nptr->groupPartnerName, nptr->groupId,
                        nptr->assignmentId, nptr->deadline, nptr->statusOfAssignment, nptr->offlineEvalMarks, nptr->vivaMarks);
        
        nptr->next = NULL;
        lptr->next = nptr;
        lptr = nptr;
    
        assignmentRecord *nptr1, *aptr1;
        studentAssignmentRecord  *lptr2, *nptr2, *aptr2;
        flag = 1;
        aptr1 = lptr1;

        while (aptr1 != NULL) {
            if (strcmp(nptr->assignmentId, aptr1->assignment_Id) == 0) {
                nptr2 = (studentAssignmentRecord*)malloc(sizeof(studentAssignmentRecord));
                strcpy(nptr2->studentGroupId, nptr->groupId);
                strcpy(nptr2->AssignmentStatus, nptr->statusOfAssignment);
                nptr2->MarksGiven = nptr->offlineEvalMarks;
                
                aptr2 = aptr1->studentAssignmentList;

                if (aptr1->studentAssignmentList != NULL) {
                    nptr2->next = aptr2;
                    aptr2 = nptr2;
                    
                    fclose(fp2);
                    FILE *file = fopen(filename2, "r");

                    FILE *tempFile = fopen("temp.txt", "w");
                    char newData[100];
                    snprintf(newData, sizeof(newData), "%s,%s,%.2f", nptr2->studentGroupId, nptr2->AssignmentStatus, nptr2->MarksGiven);

                    while (fgets(line, sizeof(line), file)) {
                        if (strstr(line, aptr1->assignment_Id) != NULL) {
                            fputs(line, tempFile);
                            fputs(newData, tempFile);
                            fputs("\n", tempFile);
                        } else {
                            fputs(line, tempFile);
                        }
                    }

                    fclose(file);
                    fclose(tempFile);

                    remove(filename2);
                    rename("temp.txt", filename2);
                }
                else {
                    aptr1->studentAssignmentList = nptr2;
                    nptr2->next = NULL;
                }
                flag = 0;
            }
            aptr1 = aptr1->next;
        }

        if (flag == 1){
            while (lptr1->next != NULL) {
                    lptr1 = lptr1->next;
            }

            nptr1 = (assignmentRecord*)malloc(sizeof(assignmentRecord));
            strcpy(nptr1->assignment_Id, nptr->assignmentId);
            printf("Enter Assignment Topic:\n");
            scanf(" %[^\n]", nptr1->topicName);
            printf("Enter Status of Assignment:\n");
            scanf(" %[^\n]", nptr1->assignment_Status);

            fprintf(fp2, "\n\n%s,%s,%s", nptr1->assignment_Id, nptr1->topicName, nptr1->assignment_Status);
         
            nptr1->studentAssignmentList = lptr2;
           
            nptr2 = (studentAssignmentRecord*)malloc(sizeof(studentAssignmentRecord));
          
            strcpy(nptr2->studentGroupId, nptr->groupId);
            strcpy(nptr2->AssignmentStatus, nptr->statusOfAssignment);
            nptr2->MarksGiven = nptr->offlineEvalMarks;
         
            fprintf(fp2, "\n%s,%s,%.2f", nptr2->studentGroupId, nptr2->AssignmentStatus, nptr2->MarksGiven);
    
            nptr2->next = NULL;
         
            if (nptr1->studentAssignmentList == NULL) {
               nptr1->studentAssignmentList = nptr2;
               //nptr2->next = NULL;
            }

            nptr1->next = NULL;
            lptr1->next = nptr1;
            lptr1 = nptr1;
        }
    }
    fclose(fp1);
    fclose(fp2);   
}

void insertAssignmentRecord(char *filename, assignmentRecord *lptr1, int numRecords) {
    FILE *fp = fopen(filename, "a");
    char line[1000];
    int i;
    assignmentRecord *nptr1;

    for (i = 0; i<numRecords; i++) {
        while (lptr1->next != NULL) {
            lptr1 = lptr1->next;
        }
        nptr1 = (assignmentRecord*)malloc(sizeof(assignmentRecord));

        printf("Enter Assignment ID:\n");
        scanf(" %s", nptr1->assignment_Id);
        printf("Enter Assignment Topic:\n");
        scanf(" %[^\n]", nptr1->topicName);
        printf("Enter Status of Assignment:\n");
        scanf(" %[^\n]", nptr1->assignment_Status);
        printf ("\n");
        fprintf(fp, "\n\n%s,%s,%s", nptr1->assignment_Id, nptr1->topicName, nptr1->assignment_Status);
        
        nptr1->next = NULL;
        lptr1->next = nptr1;
        lptr1 = nptr1;
    }
}

void printDeclaredAssignments(assignmentRecord *lptr) {
    while (lptr != NULL) {
        if (strncmp(lptr->assignment_Status, "evaluated", strlen("evaluated")) != 0) {
            printf("Assignment ID: %s\nAssignment Topic: %s\n", lptr->assignment_Id, lptr->topicName);
        }
        lptr = lptr->next;
    }
    printf("\n");
}

void printDueDateOverAssignments(assignmentRecord *lptr) {
    while (lptr != NULL) {
        if (strncmp(lptr->assignment_Status, "due date over", strlen("due date over")) == 0) {
            studentAssignmentRecord *nptr = lptr->studentAssignmentList;
            printf("Assignment ID: %s\n", lptr->assignment_Id);
            while (nptr != NULL) {
                if (strncmp(nptr->AssignmentStatus, "not submitted", strlen("not submitted")) == 0) {
                    printf("Student Group ID: %s\n", nptr->studentGroupId);
                }
                nptr = nptr->next;
            }
        }
        lptr = lptr->next;
    }
    printf("\n");
}

/*studentRecord* divideList(studentRecord *lptr) {
    studentRecord* slow = lptr;
    studentRecord* fast = lptr->next->next;
    studentRecord* nptr;

    while (fast != NULL) {
        slow = slow->next;
        fast = fast->next;

        if(fast != NULL) {
            fast = fast->next;
        }
    }
    nptr = slow->next;
    slow->next = NULL;

    return nptr;
}

studentRecord* merge (studentRecord* lptr, studentRecord* nptr) {
    studentRecord *ptr1, *ptr2, *result, *tail;
    ptr1 = lptr;
    ptr2 = nptr;

    if ((ptr1->offlineEvalMarks + ptr1->vivaMarks) < (ptr2->offlineEvalMarks + ptr2->vivaMarks)) {
        result = ptr1;
        ptr1 = ptr1->next;
    }
    else if ((ptr1->offlineEvalMarks + ptr1->vivaMarks) >= (ptr2->offlineEvalMarks + ptr2->vivaMarks)) {
        result = ptr2;
        ptr2 = ptr2->next;
    }

    tail = result;

    while (ptr1 != NULL && ptr2 != NULL) {
        if ((ptr1->offlineEvalMarks + ptr1->vivaMarks) < (ptr2->offlineEvalMarks + ptr2->vivaMarks)) {
            tail = tail->next = ptr1;
            ptr1 = ptr1->next;
        }
        
        else if ((ptr1->offlineEvalMarks + ptr1->vivaMarks) >= (ptr2->offlineEvalMarks + ptr2->vivaMarks)) {
            tail = tail->next = ptr2;
            ptr2 = ptr2->next;
        }
    }

    if (ptr1 != NULL){
        tail = tail->next = ptr1;
    }
    else {
        tail = tail->next = ptr2;
    }

    return result;
}

studentRecord* mergeSort(studentRecord *ptr) {
    studentRecord *nptr;
    studentRecord *lptr = ptr;
    nptr = divideList(lptr);
    lptr = mergeSort(lptr);
    nptr = mergeSort(nptr);
    lptr = merge(lptr,nptr);

    return ptr;
}

void printStudentDetailsForAssignmentId(studentRecord *lptr1, char id[5]) {
    lptr1 = mergeSort (lptr1);

    while (lptr1 != NULL) {
        if (strcmp(lptr1->assignmentId, id) == 0) {
            printf ("Marks: %f\nGroup ID: %s\n\n", (lptr1->offlineEvalMarks+lptr1->vivaMarks), lptr1->groupId);
        }
    }
}*/

int main () {
    char file1[] = "studentRecord.txt";
    char file2[] = "assignmentRecord.txt";
    char person[20];
    int choice1, choice2, choice3, flag = 0;
    long int studentID;
    char id[5] = "A01"; 

    studentRecord* nptr1 = NULL;
    assignmentRecord* nptr2 = NULL;
    nptr1 = createStudentRecord(file1);
    nptr2 = createAssignmentRecord(file2);

    while (flag == 0) {
    
        printf("Are you a Student or Teacher?\n");
        scanf("%s", person); 

        //printStudentDetailsForAssignmentId(nptr1, id);

        if (strcmp(person, "Teacher") == 0) {
            printf ("1. Enter 1 to display record of all the studnets.\n");
            printf ("2. Enter 2 to display assignments record.\n");
            printf ("3. Enter 3 to display a student's record.\n");
            printf ("4. Enter 4 to display the list student groups who have not submitted the assignments even if the due date is over.\n");
            printf ("5. Enter 5 to display those assignments which are declared but not evaluated.\n");
            printf ("6. Enter 6 to insert a new student record.\n");
            printf ("7. Enter 7 to insert a new Assignment Record:\n");
            printf ("8. Enter any key to EXIT\n");
            printf("\n");
            printf("Enter your choice1:\n");
            scanf("%d", &choice1);

            if (choice1 == 1) {
                printStudentRecord(nptr1);
                printf("\n");
            }
            else if (choice1 == 2) {
                printAssignmentRecord(nptr2);
                printf("\n");
            }
            else if (choice1 == 3) {
                printf ("Enter the Student ID:\n");
                scanf ("%ld", &studentID);
                printMyRecord (nptr1, studentID);
                printf("\n");
            }
            else if (choice1 == 4) {
                printDueDateOverAssignments(nptr2);
                printf("\n");
            }
            else if (choice1 == 5){
                printDeclaredAssignments(nptr2);
                printf("\n");
            }
            else if (choice1 == 6) {
                int numRec;
                printf("Enter the number of records you want to insert:\n");
                scanf("%d", &numRec);
                insertRecord(file1, file2, nptr1, nptr2, numRec);
                printf("\n");
            }
            else if (choice1 == 7) {
                int numRec;
                printf("Enter the number of records you want to insert:\n");
                scanf("%d", &numRec);
                insertAssignmentRecord(file2, nptr2, numRec);
                printf("\n");
            }
            else {
                flag = 1;
            }
        }
        
        else if (strcmp(person, "Student") == 0) {
            printf ("1. Enter 1 to see your assignment details.\n");
            printf ("2. Enter any key to EXIT!\n");
            printf ("\n");

            printf ("Enter your choice:\n");
            scanf ("%d", &choice2);

            if (choice2 == 1) {
                printf ("Enter the Student ID:\n");
                scanf ("%ld", &studentID);
                printMyRecord (nptr1, studentID);
                printf("\n");
            }
            else {
                flag = 1;
            }
        }

        else {
            printf ("1. Enter 1 to continue:\n");
            printf ("2. Enter any key to EXIT!\n");
            printf ("\n");

            printf ("Enter your choice:\n");
            scanf ("%d", &choice3);

            if (choice3 == 1) {
                flag = 0;
            }
            else {
                flag = 1;
            }
        }
    }
    return 0;
}